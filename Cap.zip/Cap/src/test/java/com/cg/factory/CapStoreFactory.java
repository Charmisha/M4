package com.cg.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CapStoreFactory {

	WebDriver driver;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[1]/a")
	@CacheLookup
	private WebElement homeLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[2]/a")
	@CacheLookup
	private WebElement getCustomersLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[3]/a")
	@CacheLookup
	private WebElement getMerchantsLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[4]/a")
	@CacheLookup
	private WebElement addMerchatLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[5]/a")
	@CacheLookup
	private WebElement deleteMerchantLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[6]/a")
	@CacheLookup
	private WebElement generateCouponsLink;

	@FindBy(how = How.XPATH, using = "/html/body/div/table/tbody/tr/td[7]/a")
	@CacheLookup
	private WebElement chatLink;

	public CapStoreFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getHomeLink() {
		return homeLink;
	}

	public void setHomeLink(WebElement homeLink) {
		this.homeLink = homeLink;
	}

	public WebElement getGetCustomersLink() {
		return getCustomersLink;
	}

	public void setGetCustomersLink(WebElement getCustomersLink) {
		this.getCustomersLink = getCustomersLink;
	}

	public WebElement getGetMerchantsLink() {
		return getMerchantsLink;
	}

	public void setGetMerchantsLink(WebElement getMerchantsLink) {
		this.getMerchantsLink = getMerchantsLink;
	}

	public WebElement getAddMerchatLink() {
		return addMerchatLink;
	}

	public void setAddMerchatLink(WebElement addMerchatLink) {
		this.addMerchatLink = addMerchatLink;
	}

	public WebElement getDeleteMerchantLink() {
		return deleteMerchantLink;
	}

	public void setDeleteMerchantLink(WebElement deleteMerchantLink) {
		this.deleteMerchantLink = deleteMerchantLink;
	}

	public WebElement getGenerateCouponsLink() {
		return generateCouponsLink;
	}

	public void setGenerateCouponsLink(WebElement generateCouponsLink) {
		this.generateCouponsLink = generateCouponsLink;
	}

	public WebElement getChatLink() {
		return chatLink;
	}

	public void setChatLink(WebElement chatLink) {
		this.chatLink = chatLink;
	}

}
