package com.cg.cap;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.factory.CapStoreFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class CapStoreSteps {
	
	private WebDriver driver;
	CapStoreFactory capStoreFactory;
	private String title;
	boolean present=false;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\user\\eclipse-workspace\\Cap\\Driver\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on the Admin Profile Page$")
	public void user_is_on_the_Admin_Profile_Page() {
		//write driver.get(" ");
		capStoreFactory =new CapStoreFactory(driver);
		
	}

	@When("^user clicks on the Home link$")
	public void user_clicks_on_the_Home_link() {
		capStoreFactory.getHomeLink().click();
	}

	@Then("^check that the text 'WELCOME TO CAPSTORE' is displayed$")
	public void check_that_the_text_WELCOME_TO_CAPSTORE_is_displayed() {
		
		driver.getPageSource().contains("WELCOME TO CAPSTORE");
		
	}

	@When("^user clicks on the Get Customers link$")
	public void user_clicks_on_the_Get_Customers_link() {
		
		capStoreFactory.getGetCustomersLink().click();
	}

	@Then("^check Customer Details are displayed$")
	public void check_Customer_Details_are_displayed() {
		//write
		
	}

	@When("^user clicks on the Get Merchants link$")
	public void user_clicks_on_the_Get_Merchants_link() {
		capStoreFactory.getGetMerchantsLink().click();
	}

	@Then("^check Merchants Details are displayed$")
	public void check_Merchants_Details_are_displayed() {
		
		//write
	}

	@When("^user clicks on the Add Merchant link$")
	public void user_clicks_on_the_Add_Merchant_link() {
		
		capStoreFactory.getAddMerchatLink().click();
		
	}

	@Then("^check that the text 'ADD MERCHANT'  is displayed$")
	public void check_that_the_text_ADD_MERCHANT_is_displayed() {
		
		driver.getPageSource().contains("ADD MERCHANT");
	}

	@When("^user clicks on the Delete Merchant link$")
	public void user_clicks_on_the_Delete_Merchant_link() {
		
		capStoreFactory.getDeleteMerchantLink().click();
		
	}

	@Then("^check that the text 'DELETE MERCHANT' is displayed$")
	public void check_that_the_text_DELETE_MERCHANT_is_displayed() {
		
		driver.getPageSource().contains("DELETE MERCHANT");
	}

	@When("^user clicks on the Generate Coupons link$")
	public void user_clicks_on_the_Generate_Coupons_link() {
		
		capStoreFactory.getGenerateCouponsLink().click();
	}

	@Then("^check that the text 'GENERATE COUPONS' is displayed$")
	public void check_that_the_text_GENERATE_COUPONS_is_displayed() {
		
		driver.getPageSource().contains("GENERATE COUPONS");
		
	}

	@When("^user clicks on the Chat link$")
	public void user_clicks_on_the_Chat_link() {
		
		capStoreFactory.getChatLink().click();
	}

	@Then("^check that the text 'CHAT' is displayed$")
	public void check_that_the_text_CHAT_is_displayed() {
		
		driver.getPageSource().contains("CHAT");
	}


	
	

	
	

}
