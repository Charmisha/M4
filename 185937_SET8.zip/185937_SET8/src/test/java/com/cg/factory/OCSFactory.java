package com.cg.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class OCSFactory {
	
WebDriver driver;
	
	@FindBy(how=How.ID, using="fname")
	@CacheLookup
	private WebElement firstName;

	@FindBy(how=How.ID, using="lname")
	@CacheLookup
	private WebElement lastName;
	
	@FindBy(how=How.ID, using="emails")
	@CacheLookup
	private WebElement email;

	@FindBy(how=How.ID, using="mobile")
	@CacheLookup
	private WebElement mobile;
	
	@FindBy(how=How.NAME, using="D6")
	@CacheLookup
	private WebElement category;
	
	@FindBy(how=How.NAME, using="D5")
	@CacheLookup
	private WebElement city;

	@FindBy(how=How.XPATH, using="/html/body/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	private WebElement modeOfLearning;

	@FindBy(how=How.XPATH, using="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	private WebElement courseDuration;
	
	@FindBy(how=How.ID, using="enqdetails")
	@CacheLookup
	private WebElement yourEnquiry;

	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	private WebElement enquireNowButton;
	
	@FindBy(how=How.ID, using="Submit2")
	@CacheLookup
	private WebElement reSetButton;

	@FindBy(how=How.XPATH, using="/html/body/form/table/tbody/tr[12]/td/a")
	@CacheLookup
	private WebElement downloadLink;

	public OCSFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getModeOfLearning() {
		return modeOfLearning;
	}

	public void setModeOfLearning(String mode) {
		this.modeOfLearning.sendKeys(mode);
	}

	public WebElement getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration.sendKeys(courseDuration);
	}

	public WebElement getYourEnquiry() {
		return yourEnquiry;
	}

	public void setYourEnquiry(String yourEnquiry) {
		this.yourEnquiry.sendKeys(yourEnquiry);
	}

	public WebElement getEnquireNowButton() {
		return enquireNowButton;
	}

	public void setEnquireNowButton() {
		this.enquireNowButton.click();
	}

	public WebElement getReSetButton() {
		return reSetButton;
	}

	public void setReSetButton() {
		this.reSetButton.click();
	}

	public WebElement getDownloadLink() {
		return downloadLink;
	}

	public void setDownloadLink() {
		this.downloadLink.click();
	}
	
	
	

}
